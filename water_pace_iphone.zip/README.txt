WATER PACE — iPhone website/app

Files:
- index.html
- manifest.webmanifest
- service-worker.js
- icon.svg

To put it on an iPhone:
1. Upload these files to any static web host (GitHub Pages, Netlify, Cloudflare Pages, etc.).
2. Open the resulting HTTPS website in Safari on your iPhone.
3. Tap Share -> Add to Home Screen -> Add.
4. Launch "Water Pace" from the Home Screen.

The tracker stores today's running total in the browser on the device.
